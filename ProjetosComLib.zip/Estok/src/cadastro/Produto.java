package cadastro;

public class Produto {
  public static void descrevaProduto() {
    System.out.println("400 canetas estão em estoque");
  }
}
