package cadastro;

public class Fornecedor {
  public static void digaOla() {
    System.out.println("Olá, eu sou o fornecedor");
  }
}
