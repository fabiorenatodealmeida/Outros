package cadastro;

public class Cliente {
  public static void digaOla() {
    System.out.println("Olá, eu sou o cliente");
    Produto.descrevaProduto();
  }
}
