package estok;

import cadastro.*;
import com.github.fabiorenatodealmeida.util.Printing;

public class Estok {
  public static void main(String[] args) {
    Cliente.digaOla();
    Fornecedor.digaOla();
    Produto.descrevaProduto();
    Printing.print();
  }
}
