package gerenciadorcontas;

import com.github.fabiorenatodealmeida.util.Printing;

public class GerenciadorContas {
  public static void main(String[] args) {
    System.out.println("Gerenciador de contas");
    Printing.print();
  }
}
