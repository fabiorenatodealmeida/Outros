package com.github.fabiorenatodealmeida.util;

public class Printing {
  public static void print() {
    System.out.println("A impressão iniciou... v.5");
  }
}
