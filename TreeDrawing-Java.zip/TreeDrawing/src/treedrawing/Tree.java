package treedrawing;

import java.util.ArrayList;

public class Tree {
  private final int MAX = 512; // Maximum number of bottom nodes
  private Node root;
  private Node[] bottom = new Node[MAX]; // Nodes at the bottom: contains the last node in each column
  private int pos = 0; // Index for the bottom array
  private int ignore_spc; // Spaces to ignore on printing due to a previously written right underscore: Node.R_
  public void Tree() {
    
  }
  public Tree(int ...values) {
    for (int value : values) {
      insert(value);
    }
  }
  public void insert(int value) {
    Node node = new Node(value);
    if (root == null) {
      root = node;
    } else {
      insert(root, node);
    }
  }
  private void insert(Node parent, Node node) {
    if (node.getValue() == parent.getValue()) return;
    if (node.getValue() < parent.getValue()) {
      if (parent.left == null) {
        parent.left = node;
      } else {
        insert(parent.left, node);
      }
    } else {
      if (parent.right == null) {
        parent.right = node;
      } else {
        insert(parent.right, node);
      }
    }
  }
  private int sz(Node node) {
    if (node == null) return 0;
    node.L_ = node.R_ = 0;
    int sz = node.len;
    if (node.left != null) {
      if (node.left.right != null) node.L_ = sz(node.left.right) + 1;
      sz += sz(node.left) + 1;
    }
    if (node.right != null) {
      if (node.right.left != null) node.R_ = sz(node.right.left) + 1;
      sz += sz(node.right) + 1;
    }
    return sz;
  }
  private void fill_bottom(Node node) {
    if (node != null) {
      if (node.left != null) fill_bottom(node.left);
      bottom[pos++] = node;
      if (node.right != null) fill_bottom(node.right);
    }
  }
  public void draw() {
    sz(root);
    fill_bottom(root);
    ArrayList<Node> nodes = new ArrayList<>();
    nodes.add(root);
    print(nodes);
  }
  private void print(ArrayList<Node> nodes) {
    int i = 0;
    ignore_spc = 0;
    for (Node node : nodes) {
      while (true) {
        if (node == bottom[i]) {
          printNode(node);
          i++;
          break;
        } else {
          printSpace(bottom[i]);
          i++;
        }
      }
    }
    System.out.println();
    i = 0;
    ignore_spc = 0;
    for (Node node : nodes) {
      while (true) {
        if (node == bottom[i]) {
          printLine(node);
          i++;
          break;
        } else {
          printSpace(bottom[i]);
          i++;
        }
      }
    }
    System.out.println();
    ArrayList<Node> next = new ArrayList<>();
    for (Node node : nodes) {
      if (node.left != null) next.add(node.left);
      if (node.right != null) next.add(node.right);
    }
    if (!next.isEmpty()) print(next);
  }
  private void printNode(Node node) {
    if (node.left != null) System.out.print(" ");
    System.out.print(node.getValue());
    if (node.right != null) System.out.print(" ");
  }
  private void printSpace(Node node) {
    if (node.left != null) {
      if (ignore_spc > 0) {
        ignore_spc--;
      } else {
        System.out.print(" ");
      }
    }
    for (int i = 0; i < node.len; i++) {
      if (ignore_spc > 0) {
        ignore_spc--;
      } else {
        System.out.print(" ");
      }
    }
    if (node.right != null) {
      if (ignore_spc > 0) {
        ignore_spc--;
      } else {
        System.out.print(" ");
      }
    }
  }
  private void printLine(Node node) {
    if (node.left != null) {
      for (int i = 0; i < node.L_; i++) System.out.print("\b");
    }
    if (node.left != null) {
      for (int i = 0; i < node.L_; i++) System.out.print("_");
      System.out.print("/");
    }
    for (int i = 0; i < node.len; i++) System.out.print(" ");
    if (node.right != null) {
      System.out.print("\\");
      for (int i = 0; i < node.R_; i++) System.out.print("_");
      ignore_spc += node.R_;
    }
  }
}
