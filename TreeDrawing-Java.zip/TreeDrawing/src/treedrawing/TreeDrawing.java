package treedrawing;

import java.util.Random;

public class TreeDrawing {
  public static void main(String[] args) {
    new Tree(7000, 7001, 4, 3, 5002, 5001, 6000).draw();
    new Tree(8, 3, 10, 2, 6, 7, 1001, 99, 98, 97, 90, 80, 81, 89, 70, 88, 87, 86, 85).draw();
    new Tree(8, 3, 10, 1, 6, 14, 4, 7, 13).draw();
    new Tree(25, 19, 36, 14, 23, 29, 52).draw();
    new Tree(7, 3, 12, 1, 6, 9, 13, 0, 2, 4, 8, 11, 15, 5, 10, 14).draw();
    new Tree(15, 11, 26, 8, 12, 20, 30, 6, 9, 14, 35).draw();
    new Tree(60, 50, 70, 40, 55, 65, 80, 30, 45, 53, 58, 63, 68, 75, 90, 25, 35, 42).draw();
    new Tree(44, 17, 78, 32, 50, 88, 48, 62, 84, 92, 80, 82).draw();
    new Tree(1, 2, 3, 4, 5, 6, 7, 0).draw();
    new Tree(7, 6, 5, 4, 3, 2, 8, 9).draw();
    
    final int MAX = 30;
    int[] values = new int[MAX];
    Random random = new Random();
    for (int i = 0; i < MAX; i++) {
      values[i] = random.nextInt(1000) + 1;
    }
    Tree tree = new Tree(values);
    tree.draw();
  }
}
