package treedrawing;

public class Node {
  private int value;
  Node left;
  Node right;
  int len; // Length of the node value
  int L_, R_; // Number of underscores on the left and right side
  public Node(int value) {
    this.value = value;
    this.len = String.valueOf(value).length();
  }
  public int getValue() {
    return value;
  }
}
